#include <iostream>
#include <fstream>
#include <cctype>
#include <string>
#include <sstream>
#include <vector>

using namespace std;

class node
{
public:
    string name;
    string phone_no;
    string address;
    string email;
    node* next;

    node()
    {
        name = "";
        phone_no = "";
        address = "";
        email = "";
        next = nullptr;
    }
};

class list
{
public:
    node* head;

    list()
    {
        head = nullptr;
    }

    // Function to insert a new contact in alphabetical order
    void insert_in_order()
    {
        node* newcontact = new node;
        string name, Email, Address;
        string Phoneno;
        cout << "Please Enter the Credentials : " << endl;
        cout << "Name : ";
        cin >> name;
        cout << "\nPhone No : ";
        cin >> Phoneno;
        cout << "\nAddress : ";
        cin >> Address;
        cout << "\nEmail: ";
        cin >> Email;

        // Convert name to lowercase
        for (char& c : name)
        {
            c = tolower(c);
        }

        newcontact->name = name;
        newcontact->phone_no = Phoneno;
        newcontact->email = Email;
        newcontact->address = Address;

        if (head == nullptr || name < head->name)
        {
            // Insert at the beginning
            newcontact->next = head;
            head = newcontact;
        }
        else
        {
            // Traverse the list to find the correct position
            node* current = head;
            while (current->next != nullptr && name > current->next->name)
            {
                current = current->next;
            }

            // Insert in the middle or at the end
            newcontact->next = current->next;
            current->next = newcontact;
        }

        saveToFile(newcontact);
    }

    // Function to save the new contact in the directory
    void saveToFile(node* newcontact)
    {
        ofstream outFile("directory.csv", ios::app | ios::out);

        if (!outFile.is_open())
        {
            cout << "Error opening file for writing." << endl;
            return;
        }

        outFile << newcontact->name << ","
            << newcontact->phone_no << ","
            << newcontact->address << ","
            << newcontact->email << endl;

        outFile.close();
        cout << "Contact saved to file successfully." << endl;
    }

    // Function to display the entire directory
    void display_whole_directory()
    {
        ifstream inFile("directory.csv");

        if (!inFile.is_open())
        {
            cout << "Error opening file for reading." << endl;
            return;
        }

        node* contact = new node;
        string line;

        while (getline(inFile, line))
        {
            stringstream ss(line);
            vector<string> tokens;
            string token;

            // Split the line into tokens

            while (getline(ss, token, ','))
            {
                tokens.push_back(token);
            }

            if (tokens.size() == 4)
            {
                contact->name = tokens[0];
                contact->phone_no = tokens[1];
                contact->address = tokens[2];
                contact->email = tokens[3];

                display(contact);
            }
        }

        inFile.close();
    }

    // Function to display a contact
    void display(node* contact)
    {
        cout << " Name : " << contact->name << endl;
        cout << " Phone No : " << contact->phone_no << endl;
        cout << " Address : " << contact->address << endl;
        cout << " Email : " << contact->email << endl;
        cout << endl;
    }

    // Function to delete a contact
    void deleteContactbyname()
    {
        int counter = 0;
        string NaMe;
        cout << "ENTER THE NAME YOU WANT TO DELETE FROM THE DIRECTORY : ";
        cin >> NaMe;

        ifstream inFile("directory.csv");
        ofstream tempFile("temp.csv");

        if (!inFile.is_open() || !tempFile.is_open())
        {
            cout << "Error opening files." << endl;
            return;
        }

        node contact;
        string line;

        while (getline(inFile, line))
        {
            stringstream ss(line);
            vector<string> tokens;
            string token;

            // Split the line into tokens
            while (getline(ss, token, ','))
            {
                tokens.push_back(token);
            }

            if (tokens.size() == 4)
            {
                contact.name = tokens[0];
                contact.phone_no = tokens[1];
                contact.address = tokens[2];
                contact.email = tokens[3];

                if (contact.name != NaMe)
                {
                    tempFile << contact.name << "," << contact.phone_no << ","
                        << contact.address << "," << contact.email << endl;
                }
                else
                {
                    cout << "Record deleted successfully." << endl;
                    counter++;
                }
            }
        }

        inFile.close();
        tempFile.close();

        // Remove the original file
        if (remove("directory.csv") != 0)
        {
            cout << "Error deleting the original file." << endl;
            return;
        }

        // Rename the temporary file to the original filename
        if (rename("temp.csv", "directory.csv") != 0)
        {
            cout << "Error renaming the temporary file." << endl;
            return;
        }

        if (counter != 0)
        {
            cout << "Deleted successfully." << endl;
        }
    }
    void deletebyphoneno()
    {
        int counter = 0;
        string phone_no;
        cout << "ENTER THE NAME YOU WANT TO DELETE FROM THE DIRECTORY : ";
        cin >> phone_no;

        ifstream inFile("directory.csv");
        ofstream tempFile("temp.csv");

        if (!inFile.is_open() || !tempFile.is_open())
        {
            cout << "Error opening files." << endl;
            return;
        }

        node contact;
        string line;

        while (getline(inFile, line))
        {
            stringstream ss(line);
            vector<string> tokens;
            string token;

            // Split the line into tokens
            while (getline(ss, token, ','))
            {
                tokens.push_back(token);
            }

            if (tokens.size() == 4)
            {
                contact.name = tokens[0];
                contact.phone_no = tokens[1];
                contact.address = tokens[2];
                contact.email = tokens[3];

                if (contact.phone_no != phone_no)
                {
                    tempFile << contact.name << "," << contact.phone_no << ","
                        << contact.address << "," << contact.email << endl;
                }
                else
                {
                    cout << "Record deleted successfully." << endl;
                    counter++;
                }
            }
        }

        inFile.close();
        tempFile.close();

        // Remove the original file
        if (remove("directory.csv") != 0)
        {
            cout << "Error deleting the original file." << endl;
            return;
        }

        // Rename the temporary file to the original filename
        if (rename("temp.csv", "directory.csv") != 0)
        {
            cout << "Error renaming the temporary file." << endl;
            return;
        }

        if (counter != 0)
        {
            cout << "Deleted successfully." << endl;
        }
    }
};

// Function to register a new user
void registerUser(const string& username, const string& password)
{
    ofstream outFile("users.txt", ios::app);

    if (!outFile.is_open())
    {
        cout << "Error opening file for writing." << endl;
        return;
    }

    outFile << username << ' ' << password << endl;

    outFile.close();
}

// Function to check if a user exists and the provided password is correct
bool authenticateUser(const string& username, const string& password)
{
    ifstream read("users.txt");

    if (!read.is_open())
    {
        cout << "Error opening file for reading." << std::endl;
        return false;
    }

    string storedUsername, storedPassword;

    while (read >> storedUsername >> storedPassword)
    {
        if (storedUsername == username && storedPassword == password)
        {
            read.close();
            return true; // User authenticated
        }
    }

    read.close();
    return false; // User not found or password incorrect
}

void login(list& list1)
{
    // Clear the screen (use "cls" for Windows, "clear" for Unix-based systems)
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif

    int choice;
    do
    {
        cout << "1. Enter a new contact. \n";
        cout << "2. Delete a contact. \n";
        cout << "3. Display the whole directory \n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice)
        {
        case 1:
            list1.insert_in_order();
            break;
        case 2:
            int del_choice;
            cout << "1. Enter 1 to delete by name\n";
            cout << "2. Enter 2 to delete by phone no\n";
            cout << "Enter your choice: ";
            cin >> del_choice;

            switch (del_choice)
            {
            case 1:
                list1.deleteContactbyname();
                break;
            case 2:
                list1.deletebyphoneno();
                break;
            default:
                cout << "Invalid choice. Please enter 1 or 2.\n";
                break;
            }
            break;
        case 3:
            list1.display_whole_directory();
            break;
        case 4:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
            break;
        }
    } while (choice != 4);
}


int main()
{
    list list1;

    system("color 1e");
    int choice;
    int count = 0;

    do
    {
        system("cls");
        if (count > 0)
        {
            cout << "Invalid username or password" << endl;
            count = 0;
        }
        cout << endl;
        cout << "-----------------------------------------------\n";
        cout << "|               1. Register                   |\n";
        cout << "|               2. Login                      |\n";
        cout << "|               3. Exit                       |\n";
        cout << "-----------------------------------------------";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            string username, password;
            cout << "Enter username: ";
            cin >> username;
            cout << "Enter password: ";
            cin >> password;

            registerUser(username, password);
            cout << "User registered successfully!\n";
            break;
        }
        case 2:
        {
            string username, password;
            cout << "Enter username: ";
            cin >> username;
            cout << "Enter password: ";
            cin >> password;

            if (authenticateUser(username, password))
            {
                cout << "Login successful!\n";
                login(list1);
            }
            else
            {
                count++;
            }
            break;
        }
        case 3:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 3);

    return 0;
}